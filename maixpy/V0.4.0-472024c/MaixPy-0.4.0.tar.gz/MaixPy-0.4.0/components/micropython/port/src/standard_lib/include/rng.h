#ifndef __RNG_H
#define __RNG_H

#include "stdint.h"

uint32_t rng_get(void);

#endif

