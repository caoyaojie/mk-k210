#ifndef __MAIXPY_H
#define __MAIXPY_H

int maixpy_main();


#endif

