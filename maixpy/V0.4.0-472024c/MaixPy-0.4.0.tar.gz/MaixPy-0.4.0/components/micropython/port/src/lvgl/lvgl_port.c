

#include "lvgl.h"
#include "mpconfig.h"
#include "lvgl_port.h"
#include "lv_conf.h"

#if LV_ENABLE_GC == 1
lvgl_state_gc_t g_lvgl_state_gc;
#endif





