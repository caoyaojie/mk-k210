#ifndef __SIPEED_SYS_H
#define __SIPEED_SYS_H

void sipeed_sys_reset();

#endif
