#ifndef _SIPEEED_GPIO_H
#define _SIPEED_GPIO_H
void test_gpio(void);
#endif /* _SIPEED_GPIO_H */
