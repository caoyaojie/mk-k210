#include "math.h"

inline float roundf(float x)
{
    return (float)((int)(x));
}
